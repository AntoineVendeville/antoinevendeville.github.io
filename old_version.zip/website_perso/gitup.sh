#!/bin/bash
git add -A .
git commit -am up
git push